const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://thumbs.gfycat.com/ShadowyFoolhardyEyas-max-1mb.gif',
  'https://i.pinimg.com/originals/a0/f2/24/a0f224a9de260d448684c50bfc0fb0f8.gif',
  'https://pa1.narvii.com/6457/fba783d9bd0ad25e4e6c505b08b9ce48d6c8d1bb_hq.gif',
  'https://thumbs.gfycat.com/DecentDecimalKookaburra-size_restricted.gif',
  'https://pa1.narvii.com/6497/f1f00e41be5834f8ae6da27707f2d12ffe3a91b7_hq.gif',
  'https://4.bp.blogspot.com/-l19o9isulwY/VQHnBQNRh1I/AAAAAAAAAag/aUdybtlxOPQ/s1600/tumblr_nh2ediq8G01rydwbvo1_500.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para Atacar!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#FF4500')
        .setDescription(`${message.author}    Acaba de atacar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}