const Discord = require("discord.js");
const bot = new Discord.Client();
const snekfetch = require("snekfetch")
exports.run = async (client, message, args) => {
      if (message.mentions.users.size < 1) return message.channel.send("Você não pode dar cafuné em ninguém")
      let user = message.guild.member(message.mentions.users.first());
            message.channel.send(`${user} Você recebeu um cafuné de ${message.author.username} ❤`,{
                embed: {
                    image: {
                        url: "https://i.imgur.com/oynHZmT.gif"
                    }
                }
            })
}