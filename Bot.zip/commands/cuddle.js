const Discord = require("discord.js");
const bot = new Discord.Client();
const snekfetch = require("snekfetch")
exports.run = (client, message, args) => {
      if (message.mentions.users.size < 1) return message.channel.send(" Mencione alguém para abraçar ")
      let user = message.guild.member(message.mentions.users.first());
            message.channel.send(`${user} Você tem um abraço de ${message.author.username} ❤`,{
                embed: {
                    image: {
                        url: "https://i.imgur.com/0yAIWbg.gif"
                    }
                }
            })
} 