const Discord = require("discord.js");
const db = require("quick.db");

exports.run = async (client, message, args) => {
    if (!message.member.permissions.any(["MANAGE_GUILD", "ADMINISTRATOR"])) {
        return message.channel.send("Você não tem permissões de ** Gerenciar servidor ** para fazer isso.");
    }

    let toggling = ["disable", "enable"];
    if (!toggling.includes(args[0])) {
        return message.channel.send("Forneça opções válidas. **disable** ou **enable**.");
    }

    if (args[0] === "enable") {
        let channel = message.mentions.channels.first();
        if (!channel) return message.channel.send("Forneça o canal que você deseja tornar como um registro de auditoria.");

        await db.set(`moderation.${message.guild.id}.modlog.toggle`, true);
        await db.set(`moderation.${message.guild.id}.modlog.channel`, channel.id);
        return message.channel.send(`O registro de auditoria foi habilitado para <#${channel.id}>`);
    }

    if (args[0] === "disable") {
        let toggle = db.get(`moderation.${message.guild.id}.modlog.toggle`);
        if (!toggle || toggle == false) return message.channel.send("Acho que o log de auditoria já foi desabilitado antes.");
        await db.set(`moderation.${message.guild.id}.modlog.toggle`, false);
        await db.delete(`moderation.${message.guild.id}.modlog.channel`);
        return message.channel.send("o log de auditoria foi desativado.");
    }
}

exports.help = {
    name: "modlog",
    description: "Change/set/update atualizar as configurações de log de moderação no servidor.",
    usage: "modlog <enable | disable> <#channel>",
    example: "modlog enable #mod-log \nmodlog disable"
};

exports.conf = {
    aliases: ["audit-log", "mod-log"],
    cooldown: 8
}