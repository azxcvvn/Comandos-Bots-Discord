const Discord = require('discord.js')

module.exports.run = async(client, message, args) => {
    if(!args[0]){
        message.reply('Fale, o nome do jogador!')

        return;
    };
    var player = message.content.split(" ").slice(1).join(" ");
    var url = `https://minotar.net/armor/body/` + player + `/100.png`
    let embedskin = new Discord.MessageEmbed()
    .addField("Skin de " + player + ":", `Para baixar, [clique aqui.](https://minotar.net/armor/body/${player}/100.png)`)
    .setImage(url)
    message.channel.send(embedskin);
}