const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://thumbs.gfycat.com/AnotherVictoriousIncatern-size_restricted.gif',
  'https://i.pinimg.com/originals/a5/9d/f3/a59df307e6bb26c6c0f1d726675ee934.gif',
  'https://pa1.narvii.com/6364/e04629f667b6a0508eba45b0c0a6025f691d592c_hq.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para bater!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Tapa')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de bater em ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('kkkkk')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}