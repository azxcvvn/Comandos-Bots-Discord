const Discord = require("discord.js");
const bot = new Discord.Client();
const frames = [
	'8======D',
	'8========D',
	'8==========D',
	'8============D',
	'8==============D'
];
exports.run = async (client, message, args) => {
    const msg = await message.channel.send('8======D');
    for (const frame of frames) {
        setTimeout(() => {}, 4000);
        await msg.edit(frame);
    }
    return message;
}