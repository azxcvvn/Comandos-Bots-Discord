const Discord = require('discord.js');

exports.run = async (client, message, args) => {

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
    .setTitle(`Defesa`)
    .setColor(`#DC143C`)
    .setThumbnail(avatar)
    .setDescription(`${message.author} acaba de se defender!`)
    .setImage('https://thumbs.gfycat.com/BlushingThirstyAmericancreamdraft-small.gif') 
    .setTimestamp()
    .setThumbnail(avatar)
    .setFooter('Skip')
  await message.channel.send(embed);
};