const { MessageEmbed } = require('discord.js');

module.exports = {
    name: "server-info",
    category: "extra",
    run: async (client, message, args) => {
        let region;
        switch (message.guild.region) {
            case "europe":
                region = '🇪🇺 Europe';
                break;
            case "us-east":
                region = '🇺🇸 us-east'
                break;
            case "us-west":
                region = '🇺🇸 us-west';
                break;
            case "us-south":
                region = '🇺🇸 us-south'
                break;
            case "us-central":
                region = '🇺🇸 us-central'
                break;
        }

        const embed = new MessageEmbed()
            .setThumbnail(message.guild.iconURL({dynamic : true}))
            .setColor('#f3f3f3')
            .setTitle(`<a:config:770455405582352405> __${message.guild.name}__ server stats`)
            .addFields(
                {
                    name: "<a:whitecrown:774817765894258749> Owner: ",
                    value: message.guild.owner.user.tag,
                    inline: true
                },
                {
                    name: "<:Users:770455379485261824> Membros: ",
                    value: `Tem ${message.guild.memberCount} Membros!`,
                    inline: true
                },
                {
                    name: "<a:online:774818987258544149> Membros Online: ",
                    value: `Tem ${message.guild.members.cache.filter(m => m.user.presence.status == "online").size} Membros online!`,
                    inline: true
                },
                {
                    name: "<:devNew:774819402327523338> Bots: ",
                    value: `Tem ${message.guild.members.cache.filter(m => m.user.bot).size} bots!`,
                    inline: true
                },
                {
                    name: "<:nome:770348995271852033> Data de criação: ",
                    value: message.guild.createdAt.toLocaleDateString("en-us"),
                    inline: true
                },
                {
                    name: "<:admin:770269995955257357> Contagem de cargos: ",
                    value: `Tem ${message.guild.roles.cache.size} cargos neste servidor.`,
                    inline: true,
                },
                {
                    name: `<a:verifyblack:774820065647394826> Verified: `,
                    value: message.guild.verified ? 'Servidor Verificado' : `Servidor não verificado`,
                    inline: true
                },
                {
                    name: '<a:Boost:774818247622000651> Boosters: ',
                    value: message.guild.premiumSubscriptionCount >= 1 ? `Tem ${message.guild.premiumSubscriptionCount} Boosters` : `Não há boosters`,
                    inline: true
                },
                {
                    name: "<a:g_palmasIF:773190300666953748> Emojis: ",
                    value: message.guild.emojis.cache.size >= 1 ? `Tem ${message.guild.emojis.cache.size} emojis!` : 'Não há emojis' ,
                    inline: true
                }
            )
        await message.channel.send(embed)
    }
}