
const Discord = require("discord.js");
const bot = new Discord.Client();
const snekfetch = require("snekfetch")
exports.run = async (client, message, args) => {
      if (message.mentions.users.size < 1) return message.channel.send("Mencione alguém para cutucar")
      let user = message.guild.member(message.mentions.users.first());
            message.channel.send(`${user} Você recebeu uma cutucada de ${message.author.username} ❤`,{
                embed: {
                    image: {
                        url: "https://i.imgur.com/XMuJ7K8.gif"
                    }
                }
            })
}
 