const fetch = require("node-fetch");

module.exports.run = (client, message, args) => {
    let mesg = args.join(" ");
    if (!mesg) return message.channel.send("Por favor, diga alguma coisa.");
    
    fetch(`https://some-random-api.ml/chatbot?message=${encodeURIComponent(mesg)}`)
    .then(res => res.json())
    .then(data => {
        message.channel.send(data.response);
    });
}

module.exports.help = {
    name: "chat"
};