const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://pa1.narvii.com/6203/b67c7cd87e3089d7e1de2551faa45e089ad1c8f5_hq.gif',
  'https://i.gifer.com/L508.gif',
  'https://pa1.narvii.com/6484/eb1b4e4f3823c77c86f70ae01f19b44ff52c5c7c_hq.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para bater!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Voadora')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de chutar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Chute para os ares')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}