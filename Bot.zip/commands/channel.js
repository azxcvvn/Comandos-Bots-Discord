const discord = require('discord.js')

module.exports = {
  name:"viewchannel",
  category:"adm",
  aliases: ['viewChannel','mostrarCanal','mostrarcanal'],
  run: async (client, message, args) => {
    let amor = message.guild.roles.cache.find(callback => callback.name === '@everyone')
     if(!message.member.hasPermission("MANAGE_CHANNELS")) {
       message.channel.send('<a:Cross:774790880632504330> Você não tem permissions o suficiente falta `MANAGE_CHANNELS`')
     }
    
    message.channel.updateOverwrite(amor, {
  VIEW_CHANNEL: true
})
    
    return message.channel.send('<a:Checkmark:774790867319521320> Canal visivel com sucesso!!' + `\n` + 'Use `!Hidechannel` para deixar invisivel')
    
  }
}